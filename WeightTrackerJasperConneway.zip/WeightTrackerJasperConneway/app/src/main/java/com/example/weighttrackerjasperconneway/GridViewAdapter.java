package com.example.weighttrackerjasperconneway;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;


public class GridViewAdapter extends ArrayAdapter<Model> {

    public GridViewAdapter(Context context, ArrayList<Model> list) {
        super(context, 0, list);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View itemView = convertView;
        if (itemView == null) {
            itemView = LayoutInflater.from(getContext()).inflate(R.layout.card_item, parent, false);
        }

        Model model = getItem(position);

        TextView weightView = itemView.findViewById(R.id.weight_view);
        TextView dateView = itemView.findViewById(R.id.date_view);

        if (model != null) {
            weightView.setText(model.getWeight());
            dateView.setText(model.getDate());
        }

        return itemView;
    }
}

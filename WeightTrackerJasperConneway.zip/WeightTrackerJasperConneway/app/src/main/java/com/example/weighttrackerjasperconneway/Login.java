package com.example.weighttrackerjasperconneway;

import android.content.Intent;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Login extends AppCompatActivity {

    private EditText mUsername;
    private EditText mPassword;
    private Button mLogin;
    private Button mSignup;
    private EditText mNumber;
    private TextView txtmsg;
    private ImageView scaleImg;
    private WTDatabase db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mUsername = findViewById(R.id.userButton);
        mPassword = findViewById(R.id.passButton);
        mLogin = findViewById(R.id.loginButton);
        mSignup = findViewById(R.id.signupButton);
        mNumber = findViewById(R.id.mobileNumber);
        txtmsg = findViewById(R.id.textMessage);
        scaleImg = findViewById(R.id.scale);

        db = new WTDatabase(Login.this);

        // listen for login or sign up
        clickLoginButton();
        clickSignupButton();
    }

    public void clickLoginButton() {
        mLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            // gather user input
            public void onClick(View v) {
                String username = mUsername.getText().toString();
                String password = mPassword.getText().toString();

                // ensure input is not empty
                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(Login.this,
                            "Please enter username and password to continue.", Toast.LENGTH_SHORT).show();
                    return;
                }

                // check if input is correct
                if (db.getUser(username, password)) {
                    Toast.makeText(Login.this, "Login Successful.", Toast.LENGTH_SHORT).show();
                    // log user into main activity and send username and password for use
                    Intent intent = new Intent(Login.this, MainActivity.class);
                    intent.putExtra("username", username);
                    intent.putExtra("password", password);
                    startActivity(intent);
                }
                else {
                    // User error message - incorrect log in
                   Toast.makeText(Login.this, "Incorrect username or password.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void clickSignupButton() {
        mSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            // gather user input
            public void onClick(View v) {
                String username = mUsername.getText().toString();
                String password = mPassword.getText().toString();
                String sms = mNumber.getText().toString();

                // all variables require user input to continue
                if (username.isEmpty() || password.isEmpty() || sms.isEmpty()) {
                    Toast.makeText(Login.this,
                            "Please enter all fields to continue.", Toast.LENGTH_SHORT).show();
                    return;
                }

                // ensure username and phone number does not exist
                if (db.userExists(username, sms)) {
                    Toast.makeText(Login.this, "Account already exists. Please login.", Toast.LENGTH_SHORT).show();

                }
                else {
                    // user does not exist, create user account and send to main activity
                    db.addUser(username, password, sms);
                    Intent intent = new Intent(Login.this, MainActivity.class);
                    // save username and password for use in next activity
                    intent.putExtra("username", username);
                    intent.putExtra("password", password);
                    startActivity(intent);
                }
            }
        });
    }
}

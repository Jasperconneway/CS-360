package com.example.weighttrackerjasperconneway;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.nfc.Tag;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;


/*
 * Following the zybooks coding examples for the database
 */
public class WTDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "weightTracker.db";
    private static final int VERSION = 1;

    public WTDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);

    }

    // User table variables
    public static final class UsersTable {
        private static final String TABLE = "users";
        private static final String COL_ID = "users_id";
        private static final String COL_USER = "username";
        private static final String COL_PASS = "password";
        private static final String COL_SMS = "phone number";
    }

    // Weight table variables
    public static final class WeightTable {
        private static final String TABLE = "weight tracker";
        private static final String COL_WEIGHTID = "weight_id";
        private static final String COL_DATE = "date";
        private static final String COL_WEIGHT = "weight";
        private static final String COL_USERID = "users_id";
    }

    // Create both tables with SQL
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + UsersTable.TABLE + " (" +
                UsersTable.COL_ID + " integer primary key autoincrement, " +
                UsersTable.COL_USER + " text, " +
                UsersTable.COL_PASS + " text, " +
                UsersTable.COL_SMS + " integer not null)");

        db.execSQL("create table " + WeightTable.TABLE + " (" +
                WeightTable.COL_WEIGHTID + " integer not null primary key, " +
                WeightTable.COL_DATE + " timestamp default current_timestamp not null, " +
                WeightTable.COL_WEIGHT + " float, " +
                WeightTable.COL_USERID + " integer not null, " +
                "foreign key (WeightTable.COL_USERID) references UsersTable.TABLE(UsersTable.COL_ID))");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + UsersTable.TABLE);
        db.execSQL("drop table if exists " + WeightTable.TABLE);
        onCreate(db);
    }

    // add a new user
    public void addUser(String user, String pass, String sms) {
        SQLiteDatabase db = this.getWritableDatabase();

        // gather the variables with content values
        ContentValues values = new ContentValues();
        values.put(UsersTable.COL_USER, user);
        values.put(UsersTable.COL_PASS, pass);
        values.put(UsersTable.COL_SMS, sms);

        // add user to table
        db.insert(UsersTable.TABLE, null, values);
        db.close();
    }

    public boolean getUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        // use sql query to locate the user requested
        String sql = "select * from " + UsersTable.TABLE + " where " +
                UsersTable.COL_USER + " =?" + " and " + UsersTable.COL_PASS + " =?";
        Cursor cursor = db.rawQuery(sql, new String[] { username, password});
        // curse through db until user is found or end of db
        if (cursor.moveToFirst()) {
            do {
                String tempUser = cursor.getString(1);
                String tempPass = cursor.getString(2);

                if (username.equalsIgnoreCase(tempUser) && password.equalsIgnoreCase(tempPass)) {
                    return true;
                }
                else if (username.equalsIgnoreCase(tempUser) && !password.equalsIgnoreCase(tempPass)) {
                    return true;
                }
            } while (cursor.moveToNext());
        }

        // always close
        cursor.close();
        return false;
    }

    public boolean userExists(String username, String number) {
        SQLiteDatabase db = this.getReadableDatabase();

        // use sql query - does the user exist
        String sql = "select * from " + UsersTable.TABLE + " where " +
                UsersTable.COL_USER + " =?" + " and " + UsersTable.COL_SMS + " =?";
        Cursor cursor = db.rawQuery(sql, new String[] { username, number });
        // curse through db until user is found or end of db
        if (cursor.moveToFirst()) {
            do {
                String tempUser = cursor.getString(1);
                String tempSMS = cursor.getString(3);
                if (username.equalsIgnoreCase(tempUser) || number.equalsIgnoreCase(tempSMS)) {
                    return true;
                }
            } while (cursor.moveToNext());
        }

        // always close
        cursor.close();
        return false;
    }

    public void addWeight(String weight, String date) {
        SQLiteDatabase db = this.getWritableDatabase();

        // add new weight with date
        ContentValues values = new ContentValues();
        values.put(WeightTable.COL_WEIGHT, weight);
        values.put(WeightTable.COL_DATE, date);
        values.put(WeightTable.COL_WEIGHTID, ThreadLocalRandom.current().nextInt(0, 100));

        //insert to table
        db.insert(WeightTable.TABLE, null, values);
        db.close();
    }

    public boolean updateWeight(String weight, String weightId) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(WeightTable.COL_WEIGHT, weight);

        // update weight with weight id
        int rowsUpdated = db.update(WeightTable.TABLE, values, WeightTable.COL_WEIGHTID + " =?",
                new String[] { WeightTable.COL_WEIGHTID + " = " + weightId });

        return rowsUpdated > 0;
    }

    public boolean deleteWeight(String weightId) {
        SQLiteDatabase db = getWritableDatabase();

        // delete weight with weightId
        int rowsDeleted = db.delete(WeightTable.TABLE,
                WeightTable.COL_WEIGHTID + " =?", new String[] { weightId });


        return rowsDeleted > 0;
    }


    public ArrayList<Model> getAllUserWeight(String colId) {
        ArrayList<Model> items = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();


        // get the specific user weight in an array list using model class
        String sql = "select * from " + WeightTable.TABLE + " where " +
                WeightTable.COL_USERID + " =?";

        Cursor cursor = db.rawQuery(sql, new String[] { colId });

        // find every weight with user id
        if (cursor.moveToFirst()) {
            do {
                String tempId = cursor.getString(3);
                if (tempId.equals(colId)) {
                    String weight = cursor.getString(1);
                    String date = cursor.getString(2);
                    Model model = new Model(weight, date);
                    items.add(model);
                }
            } while (cursor.moveToNext());
        }

        // always close
        cursor.close();
        return items;
    }


    public String getUserId(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        // sql query to locate user id
        String sql = "select * from " + UsersTable.TABLE + " where " +
                UsersTable.COL_USER + " =?" + " and " + UsersTable.COL_PASS + " =?";
        Cursor cursor = db.rawQuery(sql, new String[] { username, password});
        if (cursor.moveToFirst()) {
            do {
                String tempUser = cursor.getString(1);
                String tempPass = cursor.getString(2);
                String userId = cursor.getString(3);
                if (username.equalsIgnoreCase(tempUser) && password.equalsIgnoreCase(tempPass)) {
                    return userId;
                }
            } while (cursor.moveToNext());
        }

        // always close
        cursor.close();
        return "-1"; // user id not located
    }
}

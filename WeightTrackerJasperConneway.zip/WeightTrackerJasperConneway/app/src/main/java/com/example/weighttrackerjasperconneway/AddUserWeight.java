package com.example.weighttrackerjasperconneway;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Date;

public class AddUserWeight extends AppCompatActivity {
    private WTDatabase db;
    private Button addWeight;
    private EditText weight;
    private TextView date;

    private String username;
    private String password;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_weight);

        addWeight = findViewById(R.id.setWeight);
        weight = findViewById(R.id.newWeight);
        date = findViewById(R.id.newDate);

        // gather intent from previous activity
        Intent intent = getIntent();
        username = intent.getStringExtra("username");
        password = intent.getStringExtra("password");

        db = new WTDatabase(AddUserWeight.this);

        // set weight listener
        clickSetButton();

    }


    public void clickSetButton() {
        addWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // gather weight entered
                String mWeight = weight.getText().toString();
                // create today's date
                String date = new Date().toString();


                // ensure input is not empty
                if (mWeight.isEmpty()) {
                    Toast.makeText(AddUserWeight.this,
                            "Please enter weight to continue.", Toast.LENGTH_SHORT).show();
                }
                else { // add weight to database
                    db.addWeight(mWeight, date);
                    // start activity back to MainActivity and send username and password for use
                    Toast.makeText(AddUserWeight.this, "Weight was entered.", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(AddUserWeight.this, MainActivity.class);
                    intent.putExtra("username", username);
                    intent.putExtra("password", password);
                    startActivity(intent);
                }

            }
        });
    }

}
